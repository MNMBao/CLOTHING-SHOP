<footer>
            <div class="grid">      
                <div class="account-footer">
                    <div class="grid wide">
                        <div class="row">
                            <div class="col l-2-4 c-12 m-6">
                               <div class="account-footer_titel">CHĂM SÓC KHÁCH HÀNG</div>
                               <div class="account-footer_list">
                                <ul>
                                    <li>
                                        <a href="">Trung tâm trợ giúp</a>
                                    </li>
                                    <li>
                                        <a href="">TGl Blog</a>
                                    </li>
                                    <li>
                                        <a href="">TGL Mall</a>
                                    </li>
                                    <li>
                                     <a href="">Hướng dấn mua hàng</a>
                                    </li>
                                    <li>
                                     <a href="">Hướng dấn bán hàng</a>
                                    </li>
                                </ul>
                               </div>   
                            </div>
                            <div class="col l-2-4 c-12 m-6">
                                <div class="account-footer_titel">VỀ TGl</div>
                                <div class="account-footer_list">
                                 <ul>
                                     <li>
                                         <a href="">Giới thiệu về TGL</a>
                                     </li>
                                     <li>
                                         <a href="">Tuyển dụng</a>
                                     </li>
                                     <li>
                                         <a href="">Điều khoản TGL</a>
                                     </li>
                                     <li>
                                      <a href="">Chính sách bảo mật</a>
                                     </li>
                                     <li>
                                      <a href="">Chính hãng</a>
                                     </li>
                                     <li>
                                        <a href="">Kênh người bán</a>
                                       </li>
                                 </ul>
                                </div>   
                            </div>
                            <div class="col l-2-4 c-12 m-6">
                                <div class="account-footer_titel">THEO DÕI CHÚNG TÔI TRÊN</div>
                                <div class="account-footer_list">
                                 <ul>
                                     <li>
                                         <span class="ti-facebook"></span>
                                         <a href="">Facebook</a>
                                     </li>
                                     <li>
                                        <span class="ti-google"></span>
                                        <a href="">Google</a>
                                     </li>
                                     <li>
                                        <span class="ti-instagram"></span>
                                        <a href="">Instagram</a>
                                     </li>
                                 </ul>
                                </div>  
                            </div>
                            <div class="col l-2-4 c-12 m-6">
                                <div class="account-footer_titel">THANH TOÁN</div>
                                <div class="account-footer_list">
                                 <ul>
                                     <li>
                                         <span class="ti-credit-card"></span>
                                         <a href="">Thẻ VISA</a>
                                     </li>
                                     <li>
                                        <span class="ti-shortcode"></span>
                                        <a href="">Chuyển khoản</a>
                                     </li>
                                     <li>
                                        <span class="ti-receipt"></span>
                                        <a href="">Credit</a>
                                     </li>
                                 </ul>
                                </div>  
                            </div>
                            <div class="col c-12 l-2-4 m-6">
                                <div class="account-footer_titel">TẢI ỨNG DỤNG TGL NGAY THÔI</div>
                                <div class="account-footer_list">
                                 <ul>
                                     <li>
                                         <span class="ti-apple"></span>
                                         <a href="">App Store</a>
                                     </li>
                                     <li>
                                        <span class="ti-android"></span>
                                        <a href="">Ch Play</a>
                                     </li>
                                     <li>
                                        <span class="ti-instagram"></span>
                                        <a href="">Instagram</a>
                                     </li>
                                 </ul>
                                </div>  
                            </div>
                        </div>
                        <div class="account-footer-security">
                            © 2022 MLL. Tất cả các quyền được bảo lưu dưới quyền của các thành viên Team MLL
                        </div>
                    </div>
                   
                </div>
            </div>
        </footer>