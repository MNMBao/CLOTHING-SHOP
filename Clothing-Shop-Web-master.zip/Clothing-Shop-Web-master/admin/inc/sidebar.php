<input type="checkbox" id="sidebar-toggle">
         <div class="sidebar"> 
             <div class="sidebar-header">
                 <h3 class="brand" ><span class="ti-unlink"></span>
                  <span>TGL</span>
                 </h3>
                 <label for="sidebar-toggle" class="ti-menu-alt"></label>
             </div>
             <div class="sidebar-menu">
                 <ul>
                     <li>
                         <a href="index.php">
                             <span class="ti-home"></span>
                             <span>Trang chủ</span>
                         </a>
                    </li>
                    <li>
                        <a href="listTypeProduct.php">
                            <span class="ti-face-smile" ></span>
                            <span>Kiểu sản phẩm</span>
                        </a>
                    </li>
                    <li>
                        <a href="catlist.php">
                            <span class="ti-face-smile" ></span>
                            <span>Danh mục sản phẩm</span>
                        </a>
                    </li>
                    <li>
                        <a href="brandlist.php">
                            <span class="ti-face-smile" ></span>
                            <span>Thương hiệu sản phẩm</span>
                        </a>
                    </li>
                    <li>
                        <a href="productlist.php">
                            <span class="ti-agenda"></span>
                            <span>Danh sách sản phẩm</span>
                        </a>
                    </li>
                    <li>
                        <a href="quanlydonhang.php">
                            <span class="ti-agenda"></span>
                            <span>Quản lý đơn hàng</span>
                        </a>
                    </li>
                    <li>
                        <a href="thongke.php">
                            <span class="ti-clipboard"></span>
                            <span>Thống kê tình hình</span>
                        </a>
                    </li>
                    <li>
                        <a href="thongtinkh.php">
                            <span class="ti-folder"></span>
                            <span>Thông tin khách hàng</span>
                        </a>
                    </li>
                    <li>
                        <a href="discountList.php">
                            <span class="ti-folder"></span>
                            <span>Voucher khuyễn mãi</span>
                        </a>
                    </li>
                    <li>
                        <a href="account.php">
                            <span class="ti-settings"></span>
                            <span>Tài khoản</span>
                        </a>
                    </li>
                 </ul>
             </div>
         </div>