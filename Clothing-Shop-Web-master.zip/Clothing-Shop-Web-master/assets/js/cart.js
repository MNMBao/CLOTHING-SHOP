
function down(i){
    let btn_down = document.getElementById('id'+i).value;
    if(btn_down>1)
    btn_down--
    document.getElementById('id'+i).value=btn_down
}

